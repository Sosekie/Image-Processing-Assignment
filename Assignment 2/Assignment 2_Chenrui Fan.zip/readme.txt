# Full Name: Chenrui Fan

# Surname: Fan

# Link to My GitHub:

https://github.com/Sosekie/Image-Processing-Assignment/blob/main/Assignment%202/color%20table.ipynb

# Description of My Algorithm:

Because the algorithm has a lot of details, I have written detailed design ideas in the code comments, which you can view in the code.

I believe I have written it in such detail that you can understand my logical sequence once you read it!
